import React, { useEffect, useRef } from 'react';
import { MenuData, AVAILABLE_FONTS, SectionStyles } from '../types';

interface ForwardedRef<T> {
  readonly current: T | null;
}

interface PrintableMenuProps {
  data: MenuData;
}

const PrintableMenu = React.forwardRef<HTMLDivElement, PrintableMenuProps>(({ data }, ref) => {
    const rootRef = useRef<HTMLDivElement>(null);

    // Sync the forwarded ref with our internal ref
    useEffect(() => {
      if (!ref) return;
      
      if (typeof ref === 'function') {
        ref(rootRef.current);
      } else {
        ref.current = rootRef.current;
      }
    }, [ref]);

    useEffect(() => {
      // Load fonts when they change
      const loadFonts = () => {
        try {
          const primaryFont = AVAILABLE_FONTS.find(f => f.value === (data.styles.primaryFont || data.styles.font));
          const secondaryFont = AVAILABLE_FONTS.find(f => f.value === data.styles.secondaryFont);
        
          const loadFont = (font: typeof AVAILABLE_FONTS[number]) => {
            if (font?.url && !document.querySelector(`link[href="${font.url}"]`)) {
              const link = document.createElement('link');
              link.href = font.url;
              link.rel = 'stylesheet';
              document.head.appendChild(link);
            }
          };

          if (primaryFont) loadFont(primaryFont);
          if (secondaryFont) loadFont(secondaryFont);
        } catch (error) {
          console.error('Error loading fonts:', error);
        }
      };

      loadFonts();
    }, [data.styles.primaryFont, data.styles.secondaryFont, data.styles.font]);

    const contentRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
      const addPageBreakIndicators = () => {
        if (!contentRef.current) return;

        // Remove existing indicators and headers
        const existingElements = document.querySelectorAll('.page-break-indicator, .page-header');
        existingElements.forEach(element => element.remove());

        // A4 dimensions in millimeters (width increased by 20%)
        const A4 = {
          width: 210, // Original 210mm * 1.2
          height: 297,
          marginTop: 0,    // 30mm top margin
          marginBottom: 0, // 30mm bottom margin
          marginLeft: 0,   // 25mm left margin
          marginRight: 0,  // 25mm right margin
        };

        // Convert mm to px for screen display (96 DPI = 3.78 px/mm)
        const MM_TO_PX = 3.78;
        
        // Get the actual content height
        const content = contentRef.current;
        const contentHeight = content.scrollHeight;
        
        // Calculate usable page height in pixels
        const usablePageHeight = (A4.height - A4.marginTop - A4.marginBottom) * MM_TO_PX;
        
        // Calculate total pages needed
        const totalPages = Math.ceil(contentHeight / usablePageHeight);

        // Create container for indicators
        const container = document.createElement('div');
        container.className = 'page-break-indicators';
        container.style.cssText = `
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          pointer-events: none;
          z-index: 50;
        `;

        // Add page break indicators
        for (let i = 1; i < totalPages; i++) {
          const topPosition = i * usablePageHeight;
          
          // Add restaurant name header for each page
          if (data.showRestaurantName !== false) {
            const header = document.createElement('div');
            header.className = 'page-header';
            header.style.cssText = `
              position: absolute;
              left: 0;
              right: 0;
              top: ${topPosition}px;
              text-align: center;
              font-size: 2.25rem;
              font-weight: 700;
              color: #111827;
              padding-top: 113px;
              padding-bottom: 2.5rem;
              font-family: ${data.styles.font || 'inherit'};
              z-index: 40;
              display: block !important;
              page-break-after: avoid;
              background: white;
            `;
            header.textContent = data.restaurantName;
            container.appendChild(header);
          }

          // Add page break indicator
          const indicator = document.createElement('div');
          indicator.className = 'page-break-indicator';
          
          indicator.style.cssText = `
            position: absolute;
            left: 0;
            right: 0;
            top: ${topPosition}px;
            pointer-events: none;
          `;
          
          // Add visual elements
          indicator.innerHTML = `
            <div style="
              position: absolute;
              left: -30px;
              right: -30px;
              border-top: 2px dashed #4F46E5;
              opacity: 0.7;
            "></div>
            <div style="
              position: absolute;
              right: -25px;
              top: -12px;
              background: #4F46E5;
              color: white;
              padding: 2px 6px;
              border-radius: 4px;
              font-size: 12px;
              opacity: 0.9;
            ">Page ${i + 1}</div>
          `;
          
          container.appendChild(indicator);
        }

        content.appendChild(container);
      };

      // Add indicators initially after content is rendered
      setTimeout(addPageBreakIndicators, 100);

      // Update indicators when window is resized
      const debouncedUpdate = debounce(addPageBreakIndicators, 100);
      window.addEventListener('resize', debouncedUpdate);

      // Update indicators when content changes
      const observer = new MutationObserver(debouncedUpdate);
      if (contentRef.current) {
        observer.observe(contentRef.current, {
          childList: true,
          subtree: true,
          characterData: true,
          attributes: true,
        });
      }

      return () => {
        window.removeEventListener('resize', debouncedUpdate);
        observer.disconnect();
      };
    }, [data]);

    function debounce(fn: Function, delay: number) {
      let timeoutId: ReturnType<typeof setTimeout>;
      return function (...args: any[]) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => fn.apply(null, args), delay);
      };
    }

    const sortedSections = data.sections.map(section => ({
      ...section,
      items: [...section.items].sort((a, b) => {
        const pluA = parseInt(a.plu) || Infinity;
        const pluB = parseInt(b.plu) || Infinity;
        return pluA - pluB;
      })
    }));

    const formatSize = (size: string | undefined) => {
      if (!size) return '';
      return size.replace('.', ',');
    };

    const mergeTypography = (sectionStyle: any, globalStyle: any) => {
      if (!sectionStyle) return globalStyle;
      return {
        fontSize: sectionStyle.fontSize || globalStyle.fontSize,
        fontWeight: sectionStyle.fontWeight || globalStyle.fontWeight,
        lineHeight: sectionStyle.lineHeight || globalStyle.lineHeight,
        letterSpacing: sectionStyle.letterSpacing || globalStyle.letterSpacing,
        transform: sectionStyle.transform || globalStyle.transform,
        fontFamily: sectionStyle.fontFamily || globalStyle.fontFamily
      };
    };

    const processText = (text: string): React.ReactNode[] => {
      if (!text) return [];
      
      const parts: React.ReactNode[] = [];
      let currentText = text;  
      while (currentText.length > 0) {
        // Check for double asterisks first
        const doubleAsteriskStart = currentText.indexOf('**');
        const singleBracketStart = currentText.indexOf('[');
        
        if (doubleAsteriskStart === -1 && singleBracketStart === -1) {
          parts.push(currentText);
          break;
        }
        
        if (doubleAsteriskStart === 0 || (doubleAsteriskStart !== -1 && (singleBracketStart === -1 || doubleAsteriskStart < singleBracketStart))) {
          // Add text before double asterisks
          if (doubleAsteriskStart > 0) {
            parts.push(currentText.substring(0, doubleAsteriskStart));
          }
          
          // Handle double asterisks
          const doubleAsteriskEnd = currentText.indexOf('**', doubleAsteriskStart + 2);
          if (doubleAsteriskEnd === -1) {
            parts.push(currentText);
            break;
          }
          
          const asteriskContent = currentText.substring(doubleAsteriskStart + 2, doubleAsteriskEnd);
          if (asteriskContent) {
            parts.push(
              <span key={`double-${doubleAsteriskStart}-${asteriskContent}`} className="text-[#949bab] font-light subpixel-antialiased">
                {asteriskContent}
              </span>
            );
          }
          currentText = currentText.substring(doubleAsteriskEnd + 2);
        } else {
          // Handle single brackets (existing superscript style)
          if (singleBracketStart > 0) {
            parts.push(currentText.substring(0, singleBracketStart));
          }
          
          const bracketEnd = currentText.indexOf(']', singleBracketStart);
          if (bracketEnd === -1) {
            parts.push(currentText.substring(singleBracketStart));
            break;
          }
          
          const bracketContent = currentText.substring(singleBracketStart + 1, bracketEnd);
          if (bracketContent) {
            parts.push(
              <span key={`single-${singleBracketStart}-${bracketContent}`} className="text-gray-800 text-[0.75em] align-super">
                {bracketContent}
              </span>
            );
          }
          currentText = currentText.substring(bracketEnd + 1);
        }
      }
      
      return parts.length > 0 ? parts : [text];
    };

    return (
      <div 
        ref={rootRef}
        className=""
      >
        {/* Cover Page */}
        <div className="z-10">
          <div 
            className="justify-center break-after-page relative px-[2mm]"
            style={{
              
              backgroundSize: 'cover',
              backgroundPosition: 'center',
              backgroundRepeat: 'no-repeat',
              backgroundColor: 'white',
              pageBreakAfter: 'always',
            }}
          >
            <div className="z-10 items-center justify-center">
              <h1
                className={`text-gray-900 antialiased text-5xl ${data.styles.sectionTitle?.fontWeight || 'font-medium'} ${data.styles.sectionTitle?.lineHeight || ''} ${data.styles.sectionTitle?.letterSpacing || ''} ${data.styles.sectionTitle?.transform || ''} text-center`}
                style={{
                  fontFamily: data.styles.sectionTitle?.fontFamily || data.styles.font || undefined,
                  WebkitFontSmoothing: 'antialiased',
                  MozOsxFontSmoothing: 'grayscale',
                  textRendering: 'optimizeLegibility'
                }}
              >
                {data.coverPage?.headline || ""}
              </h1>
           </div>
           <div 
              className="relative text-3xl text-gray-600 text-center"
              style={{
                fontFamily: data.styles.primaryFont || data.styles.font || undefined,
                WebkitFontSmoothing: 'antialiased',
                MozOsxFontSmoothing: 'grayscale',
                textRendering: 'optimizeLegibility',
                fontKerning: 'normal',
                fontFeatureSettings: '"kern" 1',
                fontOpticalSizing: 'auto'
              }}
            >
            <div className="h-[810px]">
              <img 
                src="assets/coupon.png"
                alt="Special Offer" 
                className="w-full h-full object-contain"
              />
            </div></div>
            <div 
              className="text-xl text-gray-600 text-center leaning-tighter"
              style={{
                fontFamily: data.styles.secondaryFont || data.styles.font || undefined,
                WebkitFontSmoothing: 'antialiased',
                MozOsxFontSmoothing: 'grayscale',
                textRendering: 'optimizeLegibility',
                fontKerning: 'normal',
                fontFeatureSettings: '"kern" 1',
                fontOpticalSizing: 'auto'
              }}
            >
               
              <div className="flex relative justify-text-left mx-[50px] leaning-tighter object-contain justify-center items-top">
                <img 
                  src="assets/qr.png"
                  alt="QR Code" 
                  className="w-[100px] h-[100px] mb-[140px] mr-[25px]"
                /><span className='text-[0.9em] leading-tight pt-[20px] mr-[20px]'>{'Der QR-Code führt Sie zu unserer digitalen Speisekarte. Dort finden Sie alle Informationen zu Allergenen und Zusatzstoffen unserer Gerichte.'}</span>
              </div>
              <span className="text-[0.75em] leading-tight absolute bottom-0 left-0 right-0 px-[90px]">
                {data.coverPage?.subtitle2 || `Alle Speisen gibt es auch zum Mitnehmen. Die Preise dieser Speisekarte verstehen sich in Euro und enthalten die gesetzlich vorgeschriebene Mehrwertsteuer sowie unsere Bedienungsdienstleistung.`}</span>
            </div>
          </div>

          {/* Add logo position after cover page */}
          {data.customLogo && (
            <div className="fixed top-[0cm] right-[0cm] w-[600px] h-auto print:fixed print:top-[0cm] print:right-[0cm]">
              <img 
                src={data.customLogo}
                alt="Restaurant Logo" 
                className="w-auto h-auto object-contain"
              />
            </div>
          )}

          {/* Existing Menu Content */}
          {data.showRestaurantName !== false && (
            <h1 className="text-4xl font-bold text-center text-gray-900 antialiased">
              {data.restaurantName}
            </h1>
          )}
          
          <div className="ml-[25mm] mr-[25mm]">
            {sortedSections.map((section) => {
              const sectionTitleStyle = mergeTypography(section.styles?.sectionTitle, data.styles.sectionTitle);
              const pluStyle = mergeTypography(section.styles?.plu, data.styles.plu);
              const itemNameStyle = mergeTypography(section.styles?.itemName, data.styles.itemName);
              const descriptionStyle = mergeTypography(section.styles?.description, data.styles.description);
              const priceStyle = mergeTypography(section.styles?.price, data.styles.price);

              return (
                <div 
                  key={section.id} 
                  id={`menu-section-${section.id}`} 
                  className={`${section.forcePageBreak ? 'force-page-break' : ''} break-inside-avoid-page`}
                  style={{
                    pageBreakBefore: section.forcePageBreak ? 'always' : 'auto',
                    breakBefore: section.forcePageBreak ? 'page' : 'auto',
                    breakInside: 'avoid-page',
                    pageBreakInside: 'avoid'
                  }}
                >
                  <div className="max-w border-t border-gray-300 opacity-30"/>
                  <h2 
                    className={`text-gray-900 antialiased ${sectionTitleStyle.fontSize} ${sectionTitleStyle.fontWeight} ${sectionTitleStyle.lineHeight} ${sectionTitleStyle.letterSpacing} ${sectionTitleStyle.transform || ''}`}
                    style={{
                      fontFamily: `"${data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                     marginTop: '1.75em',
                     marginBottom: '0.75em',
                     paddingTop: '0.75em',
                       paddingBottom: '-1.5em',
                      WebkitFontSmoothing: 'antialiased',
                     MozOsxFontSmoothing: 'grayscale', 
                      textRendering: 'optimizeLegibility',
                      fontSynthesis: 'none',
                      fontKerning: 'normal',
                      fontFeatureSettings: '"kern" 1',
                     fontOpticalSizing: 'auto',
                     printColorAdjust: 'exact'
                   
                    }}
                  >
                    {processText(section.name)}
                    {section.description && (
                      <p 
                        className="block text-gray-600 text-[0.9rem] leading-tight font-normal mt-8 leading-relaxed"
                        style={{
                          fontFamily: `"${data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                          WebkitFontSmoothing: 'antialiased',
                          MozOsxFontSmoothing: 'grayscale',
                          textRendering: 'optimizeLegibility',
                          letterSpacing: '-0.01em',
                          textWrap: 'balance'
                        }}
                      >
                        {processText(section.description)}
                      </p>
                    )}
                  </h2>
                  <div className={section.showDescriptions === false ? 'space-y-1.5' : 'space-y-3'}>
                    {section.items.map((item) => (
                      <div key={item.id} className={`grid ${section.showPlu ? 'grid-cols-[55px_1fr_auto]' : 'grid-cols-[1fr_auto]'} gap-2 items-baseline`}>
                        {section.showPlu && (
                          <div 
                          className={`text-gray-900 ${pluStyle.fontSize} ${pluStyle.fontWeight} ${pluStyle.lineHeight} ${pluStyle.letterSpacing} ${pluStyle.transform || ''}`}
                          style={{
                            fontFamily: `"${data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                            WebkitFontSmoothing: 'antialiased',
                            MozOsxFontSmoothing: 'grayscale',
                            textRendering: 'optimizeLegibility',
                            transform: 'translateY(-5px)'
                          }}
                          >
                            {processText(item.plu)}
                          </div>
                        )}
                        <div>
                           <h3 
                             className={`text-gray-900 ${itemNameStyle.fontSize} ${itemNameStyle.fontWeight} ${itemNameStyle.lineHeight} ${itemNameStyle.letterSpacing} ${itemNameStyle.transform || ''}`}
                             style={{
                               fontFamily: `"${data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                               WebkitFontSmoothing: 'antialiased',
                               MozOsxFontSmoothing: 'grayscale',
                               textRendering: 'optimizeLegibility',
                               textWrap: 'balance'
                             }}
                           >
                              {processText(item.name)}
                              <span className="gap-2 ml-1.5 mr-[2mm]">
                                {(item.template?.a || item.a)?.split(',').map((a, index) => (
                                  <span key={`a-${index}`} className="inline-flex justify-center items-center rounded-full bg-[#dfdfe7] text-gray-500 w-[4mm] h-[4mm] text-[2.7mm] font-[100] shadow-lg-100" style={{ transform: 'translateY(-10px) translateX(5px)', fontFamily: "'Times New Roman', serif", display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                                    {a.trim().toUpperCase()}
                                  </span>
                                ))}
                                {(item.template?.z || item.z)?.split(',').map((z, index) => (
                                  <span key={`a-${index}`} className="inline-flex justify-center items-center rounded-full bg-[#d1e5d9] w-[5mm] h-[3mm] text-[3.2mm] font-[100] opacity-90" style={{ transform: 'translateY(-10px) translateX(20px)', fontFamily: "'Times New Roman', serif", display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}>
                                    {z.trim().toUpperCase()}
                                  </span>
                                ))}
                              </span>
                              
                            </h3>
                            {section.showDescriptions !== false && (
                              <p className={`text-gray-600 ${descriptionStyle.fontSize} ${descriptionStyle.fontWeight} ${descriptionStyle.lineHeight} ${descriptionStyle.letterSpacing} ${descriptionStyle.transform || ''}`}
                                style={{
                                  fontFamily: `"${data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                                  WebkitFontSmoothing: 'antialiased',
                                  MozOsxFontSmoothing: 'grayscale',
                                  textRendering: 'optimizeLegibility',
                                  textWrap: 'balance'
                                }}>
                                {processText(item.description)}
                              </p>
                            )}
                        </div>
                        <div 
                          className={`text-right text-gray-900 flex items-baseline gap-3 ${priceStyle.fontSize} ${priceStyle.fontWeight} ${priceStyle.lineHeight} ${priceStyle.letterSpacing} ${priceStyle.transform || ''}`}
                          style={{
                            fontFamily: `"${data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || 'Crimson Pro'}", serif`,
                            WebkitFontSmoothing: 'antialiased',
                            MozOsxFontSmoothing: 'grayscale',
                            textRendering: 'optimizeLegibility'
                          }}
                        >
                          {item.prices.map((price, index) => (
                            <React.Fragment key={index}>
                              {index > 0 && <span className="text-gray-400 mx-1">·</span>}
                              <div className="whitespace-nowrap flex items-baseline gap-2">
                                {price.size && (
                                  <span 
                                    className="text-gray-600"
                                    style={{
                                      fontFamily: data.styles.secondaryFont || data.styles.primaryFont || data.styles.font || undefined,
                                      WebkitFontSmoothing: 'antialiased',
                                      MozOsxFontSmoothing: 'grayscale',
                                      textRendering: 'optimizeLegibility'
                                    }}
                                  >
                                    {processText(formatSize(price.size))}
                                  </span>
                                )}
                                <span>{price.price.toFixed(1)} €</span>
                              </div>
                            </React.Fragment>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  });

PrintableMenu.displayName = 'PrintableMenu';

export { PrintableMenu }
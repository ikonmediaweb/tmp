import React from "react";
import { Globe, Building2, Key, Mail } from "lucide-react";

interface WebsiteProviderSectionProps {
  providerName: string;
  providerUsername: string;
  onSave?: () => void;
}

const WebsiteProviderSection: React.FC<WebsiteProviderSectionProps> = ({
  providerName,
  providerUsername,
  onSave
}) => {
  return (
    <div className="max-w-[975px] mx-auto">
      <div className="bg-white rounded-lg p-8">
        <div className="flex flex-col items-center space-y-4">
          <div className="w-[80px] h-[80px] rounded-lg bg-[#FAFAFA] border border-[#DBDBDB] flex items-center justify-center">
            <Building2 size={40} className="text-[#262626]" />
          </div>

          <div className="text-center">
            <h2 className="text-[20px] font-semibold text-[#262626]">{providerName}</h2>
            <p className="text-[14px] text-[#8E8E8E]">Website-Anbieter</p>
          </div>

          <div className="w-full max-w-[355px] space-y-4">
            <div className="flex items-center justify-between py-3 border-b border-[#DBDBDB]">
              <div className="flex items-center space-x-3">
                <Globe size={20} className="text-[#262626]" />
                <span className="text-[16px] text-[#262626]">Domain</span>
              </div>
              <button className="text-[16px] text-[#0095F6] font-semibold">Hinzufügen</button>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-[#DBDBDB]">
              <div className="flex items-center space-x-3">
                <Mail size={20} className="text-[#262626]" />
                <span className="text-[16px] text-[#262626]">Benutzername</span>
              </div>
              <span className="text-[16px] text-[#262626]">{providerUsername}</span>
            </div>

            <div className="flex items-center justify-between py-3 border-b border-[#DBDBDB]">
              <div className="flex items-center space-x-3">
                <Key size={20} className="text-[#262626]" />
                <span className="text-[16px] text-[#262626]">Passwort</span>
              <button className="text-[16px] text-[#0095F6] font-semibold">Ändern</button>
              </div>
            </div>
          </div>

          <button 
            onClick={onSave}
            className="w-full max-w-[355px] bg-[#0095F6] text-white text-[14px] font-semibold py-3 rounded-lg hover:bg-[#0081d6] transition-colors"
          >
            Speichern
          </button>
        </div>
      </div>
    </div>
  );
};


export default WebsiteProviderSection